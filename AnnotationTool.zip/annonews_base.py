# Basic annotation tool for newspapers
# Author: Hui-Yin Wu
# Last modification: 29 June 2020
# Input: image file
# Output: json annotation and cropped regions
# Usage: python annonews_base.py [path/to/image/file.ext] [optional: scale_factor]

import sys, os
import random as rand
import json
from bs4 import BeautifulSoup
import math
import numpy as np

from functools import partial

# image processing
import cv2

# Basic PyQt5 libraries
from PySide2.QtCore import Qt,QRectF,QPoint
from PySide2.QtWidgets import QApplication, QLabel, QWidget, QVBoxLayout, QPushButton, QButtonGroup, QCheckBox

## Painting related libraries
from PySide2.QtGui import QPainter, QColor, QFont, QIcon, QPixmap, QPen, QPalette, QPolygon

def formatJson(jFormatted, outputName, widthMargin, heightMargin):
	dimensions = []
	print('Formatting JSON file...')
	minX = jFormatted["0"]['points'][0][0]
	maxX = minX
	minY = jFormatted["0"]['points'][0][1]
	maxY = minY
	for item in jFormatted:
		points = jFormatted[item]["points"]
		x0 = min([points[i][0] for i in range(len(points))])
		x1 = max([points[i][0] for i in range(len(points))])
		y0 = min([points[i][1] for i in range(len(points))])
		y1 = max([points[i][1] for i in range(len(points))])

		sorted_points = list(points)
		sorted_points.sort()
		bottom_left_x, bottom_left_y = sorted_points[1]
		width = int(x1 - x0)
		height = int(y1 - y0)
		dimensions.append(["rect"+item, int(bottom_left_x), int(bottom_left_y),width, height])

		if x0 < minX:
			minX = x0
		if x1 > maxX:
			maxX = x1
		if y0 < minY:
			minY = y0
		if y1 > maxY:
			maxY = y1
		
		outputFile = open(outputName, mode="w")
		binWidth = int(maxX - minX)
		binHeight = int(maxY - minY)
	
	hormargin = int((widthMargin - binWidth)/2)
	vermargin = int((heightMargin - binHeight)/2)
	outputFile.write(str(binWidth) + " " + str(binHeight)+  " " + str(hormargin)+ " " + str(vermargin)+  "\n")
	outputFile.write(str(len(dimensions)) + "\n")

	for item in dimensions:
		item[1]-=int(minX)
		item[2]-=int(minY)

		item[2]= binHeight - item[2]

		line = ' '.join(map(str, item))
		outputFile.write(line + '\n')
	
	outputFile.close()
	print("File created!")

## This class defines polygon regions
class MyPolygon():
	count = 0

	items = sorted([
		"article","column","image","heading","whatever"
		])

	c_items = {i:QColor(rand.randint(0,200),rand.randint(0,200),rand.randint(0,200)) for i in items}

	@staticmethod
	def getItemColor(item):
		return MyPolygon.c_items[item]

	def __init__(self):
		
		self.myItems = []
		self.points = []
		self.id = MyPolygon.count
		MyPolygon.count = MyPolygon.count+1

	def setItem(self,item):
		if item not in self.myItems:
			self.myItems.append(item)
		else: self.myItems.remove(item)

	def addVertice(self,x,y):
		
		self.points.append([x,y])
	
	def deleteLastVertice(self):
		if len(self.points) > 0:
			self.points.pop()
	
	def alignLastVertice(self):
		if abs(self.points[-1][0] - self.points[0][0]) < abs(self.points[-1][1] - self.points[0][1]):
			self.points[-1][0] = self.points[0][0]
		else: self.points[-1][1] = self.points[0][1]
		

class MyUI(QWidget):
	def __init__(self,imgName,scale=0.8):
		super().__init__()
		self.image = imgName.strip().split("/")[-1]
		self.path = "/".join(imgName.strip().split("/")[0:2]) + "/"
		self.imgName = imgName
		self.scale=scale
		self.initUI()
		print(self.pixmap.width(), self.pixmap.height())
		
	def initUI(self):

		## Setting up newspaper

		self.mypath = self.path
		if not os.path.exists(self.mypath):
			os.makedirs(self.mypath)

		self.pixmap = QPixmap(self.imgName)

		## A few adjustable parameters
		initY = 50
		initX = self.pixmap.width()*self.scale+50

		jCount = 0

		self.iLabel = QLabel("Items",self)
		self.iLabel.move(initX+100,initY+30*(jCount//3)+60)

		self.itemButtons = QButtonGroup()
		self.itemButtons.setExclusive(False)
		
		for i in MyPolygon.items:
			self.itemButtons.addButton(QCheckBox(i,self))

		jCount = 15

		for i in self.itemButtons.buttons():
			palette = QPalette()
			
			palette.setColor(QPalette.Button,MyPolygon.c_items[i.text()])
			
			palette.setColor(QPalette.WindowText,QColor(255,255,255))
			i.setAutoFillBackground(True)
			i.setPalette(palette)
			thresh = 100*(jCount%3)
			i.move(initX+thresh,initY+30*(jCount//3))
			jCount = jCount+1

		## Initiating the current chosen polygon as an empty one
		self.curPoly = MyPolygon()
		self.allPoly = []

		## Initiating mouse event variables
		self.mX = 0
		self.mY = 0

		self.drawing = False
		
		# New polygon button
		self.newPoly = QPushButton("(N)ew Poly",self)
		self.newPoly.move(initX, initY+30*(jCount//3)+70)
		self.newPoly.clicked.connect(lambda: self.newPolygon())

		# Undo button
		self.undoButton = QPushButton("(U)ndo",self)
		self.undoButton.move(initX, initY+30*(jCount//3)+100)
		self.undoButton.clicked.connect(lambda: self.deleteLastRect())

		# Clear tags button
		self.clearButton = QPushButton("Clear Tags",self)
		self.clearButton.move(initX+100, initY+30*(jCount//3)+100)
		self.clearButton.clicked.connect(lambda: self.clearChecks())

		# Renumber rectangles
		self.renumberButton = QPushButton("Renumber",self)
		self.renumberButton.move(initX+200, initY+30*(jCount//3)+100)
		self.renumberButton.clicked.connect(lambda: self.reNumber())

		# Crop button
		self.cropButton = QPushButton("Crop",self)
		self.cropButton.move(initX, initY+30*(jCount//3)+130)
		self.cropButton.clicked.connect(lambda: self.crop())

		# Read Annotation button
		self.readButton = QPushButton("Read",self)
		self.readButton.move(initX+100, initY+30*(jCount//3)+130)
		self.readButton.clicked.connect(lambda: self.readAnnotation())
		
		# Export button
		self.exportButton = QPushButton("Export",self)
		self.exportButton.move(initX+200, initY+30*(jCount//3)+130)
		self.exportButton.clicked.connect(lambda: self.exportJson())

		# Export HBB-NPP button
		self.exportButton = QPushButton("Export HBB-NPP",self)
		self.exportButton.move(initX+200, initY+30*(jCount//3)+160)
		self.exportButton.clicked.connect(lambda: self.exportHBB())
		
		# Switch between dot, rectangle, and label mode
		self.switchMode = QPushButton("(M)ode",self)
		self.switchMode.move(initX, initY+30*(jCount//3)+190)
		self.switchMode.clicked.connect(lambda: self.mode())
		
		self.modes = {0:"DOT",1:"RECTANGLE",2:"LABEL"}
		self.curmode = 0
		
		self.mLabel = QLabel(f': {self.modes[self.curmode]} mode',self)
		self.mLabel.move(initX+100,initY+30*(jCount//3)+190)
		
		self.sLabel = QLabel("(S)traightline mode (press and hold)",self)
		self.sLabel.move(initX+100,initY+30*(jCount//3)+220)
		
		self.aLabel = QLabel("(A)lign last vertice",self)
		self.aLabel.move(initX+100,initY+30*(jCount//3)+250)
		
		self.aLabel = QLabel("(D)elete last vertice",self)
		self.aLabel.move(initX+100,initY+30*(jCount//3)+280)

		######## Interactions #########
		
		for i in self.itemButtons.buttons():
			i.stateChanged.connect(partial(self.onToggleItem, i.text()))
		
		###############################
		
		# Some status parameters
		self.straightline = False
		self.clearingChecks = False


		self.setMouseTracking(True)

		self.resize(initX+350,self.pixmap.height()+100)
		self.setWindowTitle('News Annotator')
		
		self.initPoly = False
		self.curPolySaved = False

		self.show()
	
	def align(self):
		
		self.curPoly.alignLastVertice()
		self.update()
		
		return 0
		
	#### Crop function normal for polygon
	def crop(self):
		
		img = cv2.imread(self.imgName)
		id = 0
		
		for poly in self.allPoly:
			
			pts = np.array([[math.ceil(point[0]/self.scale),math.ceil(point[1]/self.scale)] for point in poly.points])
			rect = cv2.boundingRect(pts)
			x,y,w,h = rect
			cropped = img[y:y+h, x:x+w].copy()
			pts = pts - pts.min(axis=0)
			
			## (2) make mask
			mask = np.zeros(cropped.shape[:2], np.uint8)
			cv2.drawContours(mask, [pts], -1, (255, 255, 255), -1, cv2.LINE_AA)
			
			## (3) do bit-op
			dst = cv2.bitwise_and(cropped, cropped, mask=mask)
			
			for i in poly.myItems:
				if not os.path.exists(self.mypath+"/"+i+"/"):
					os.makedirs(self.mypath+"/"+i+"/")
				cv2.imwrite(self.mypath+"/"+i+"/rect"+str(id)+'.jpg',dst)
			id = id+1
	
	def exportHBB(self):
		jFormatted = {}
		id = 0
		for poly in self.allPoly:
			polyInfo={}
			polyInfo["points"]=[[float(round(point[0]/self.scale)),float(round(point[1]/self.scale))] for point in poly.points]
			polyInfo["items"]=poly.myItems
			jFormatted[str(id)]=polyInfo
			id = id + 1
			
		formatJson(jFormatted, self.path+(self.image).strip(".png")+".txt", self.pixmap.width(), self.pixmap.height())


	def exportJson(self):
		with open(self.path+(self.image).strip(".png")+".json","w") as outfile:
			jFormatted = {}
			id = 0
			for poly in self.allPoly:
				polyInfo={}
				polyInfo["points"]=[[float(round(point[0]/self.scale)),float(round(point[1]/self.scale))] for point in poly.points]
				polyInfo["items"]=poly.myItems
				jFormatted[str(id)]=polyInfo
				id = id + 1
			json.dump(jFormatted,outfile,indent=4)


	
	# switch between dot, rectangle, and label mode for the current annotations
	def mode(self):
		
		self.curmode = (self.curmode + 1)%3
		
		self.mLabel.setText(f": {self.modes[self.curmode]} mode")
	
	def newPolygon(self):
		self.curPolySaved = True
		self.curPoly = MyPolygon()
		for i in self.itemButtons.buttons():
			if i.isChecked():
				self.curPoly.setItem(i.text())
		self.update()

	def onToggleItem(self, item, event):
		if not self.clearingChecks :
			self.curPoly.setItem(item)
			self.update()
		
	def onClickUndo(self):
		
		self.deleteLastPoly()
	
	def clearChecks(self):
		
		for c in self.itemButtons.buttons():
			c.setChecked(False)
	
	def deleteLastPoly(self):
		self.allPoly=self.allPoly[:-1]
		self.update()
	
	##### unlinked code for polygon
	def deleteLastVertice(self):
		if self.curmode is 0 :
			self.curPoly.deleteLastVertice()
			self.update()
		
	def keyPressEvent(self, event):
		
		if event.key() == Qt.Key_U:
			self.deleteLastPoly()
		elif event.key() == Qt.Key_N:
			self.newPolygon()
		elif event.key() == Qt.Key_S:
			self.straightline = True
		elif event.key() == Qt.Key_M:
			self.mode()
		elif event.key() == Qt.Key_A:
			self.align()
		elif event.key() == Qt.Key_D:
			self.deleteLastVertice()
			
	def keyReleaseEvent(self, event):
		if event.key() == Qt.Key_S:
			self.straightline = False

	def paintEvent(self, event):
		
		qp = QPainter()
		qp.begin(self)

		qp.drawPixmap(0,0,self.pixmap.width()*self.scale,self.pixmap.height()*self.scale,self.pixmap.scaled(self.pixmap.width()*self.scale,self.pixmap.height()*self.scale))
		
		### Code for drawing event
		qpe = QPen()
		
		for poly in self.allPoly:
			
			if len(poly.points)==0:
				continue
			
			qpe.setWidth(2)
			qpe.setColor(QColor(200,200,0))
			if poly is self.curPoly:
				qpe.setColor(QColor(200,0,0))
			qp.setBrush(Qt.NoBrush)
			qp.setPen(qpe)
			
			tpolygon = QPolygon([QPoint(*point) for point in poly.points])
			
			#qp.setBrush(Qt.red)
			qp.drawPolygon(tpolygon)
			
			qp.setFont(QFont("Arial", 11, QFont.Bold))
			n = 12
			count = 0
			qp.setBrush(QColor(0,0,0))
			qpe.setColor(QColor(255,255,255))
			qp.setPen(qpe)
			
			qp.drawRect(poly.points[-1][0],poly.points[-1][1],2*n,n)
			qp.drawText(QRectF(poly.points[-1][0],poly.points[-1][1],2*n,n),Qt.AlignCenter,str(poly.id))
			
				
			for s_i in poly.myItems:
				qpe.setColor(QColor(255,255,255))
				qpe.setWidth(0)
				qp.setBrush(QColor(MyPolygon.c_items[s_i]))
				qp.setPen(Qt.NoPen)
				qp.drawRect(poly.points[0][0]+count*n,poly.points[0][1],n,n)
				qp.setPen(qpe)
				qp.drawText(QRectF(poly.points[0][0]+count*n,poly.points[0][1],n,n),Qt.AlignCenter,s_i[0].upper())
				count=count+1

		qpe.setWidth(1)
		qpe.setColor(QColor(150,150,150))
		qp.setPen(qpe)
		
		if self.mY <= self.pixmap.height()*self.scale and self.mX <= self.pixmap.width()*self.scale:
			qp.drawLine(0,self.mY,self.pixmap.width()*self.scale,self.mY)
			qp.drawLine(self.mX,0,self.mX,self.pixmap.height()*self.scale)
		qp.end()

	def mouseMoveEvent(self,e):
		self.mX = e.x()
		self.mY = e.y()

		if self.drawing and self.curmode == 1:
			
			self.curPoly.points = [self.curPoly.points[0]] + [[self.mX,self.curPoly.points[0][1]],[self.mX,self.mY],[self.curPoly.points[0][0],self.mY]]
		elif self.drawing and self.curmode == 0:
			
			x = self.mX
			y = self.mY
			
			if self.straightline and len(self.curPoly.points)>1:
				if abs(self.curPoly.points[-2][0]-x)>abs(self.curPoly.points[-2][1]-y):
					y = self.curPoly.points[-2][1]
				else: 
					x = self.curPoly.points[-2][0]
			
			self.curPoly.points = self.curPoly.points[:-1] + [[x,y]]
		self.update()
	
	def mousePressEvent(self,e):
		
		if self.mY <= self.pixmap.height()*self.scale and self.mX <= self.pixmap.width()*self.scale and self.curmode < 2:
			if (not self.initPoly) or self.curPolySaved :
				self.allPoly.append(self.curPoly)
				self.curPolySaved = False
			self.initPoly = True
			
			if self.curmode == 1 :
				self.curPoly.points = []
			self.curPoly.addVertice(self.mX,self.mY)

				
			self.drawing = True
				
		elif self.curmode == 2:
			
			self.curPolySaved = True
			
			
			for poly in self.allPoly :
				
				if len(poly.points)==0:
					continue
				
				tpolygon = QPolygon([QPoint(*point) for point in poly.points])
				
				if tpolygon.containsPoint(QPoint(self.mX, self.mY),Qt.OddEvenFill):
					
					
					self.curPoly = poly
					self.curPolySaved = False
					
					# clear all the checked labels from the previous polygon and load the current one
					
					
					self.clearingChecks = True
					
					for i in self.itemButtons.buttons() : 
						if i.text() in self.curPoly.myItems:
							i.setChecked(True)
						else : i.setChecked(False)
					
					
					self.clearingChecks = False
					
					
					break
	
	def mouseReleaseEvent(self,e):
		
		self.drawing = False
			
		self.update()

	def readAnnotation(self):
		
		filename = self.path+(self.image).strip(".png")+".json"

		with open(filename) as json_file:
			data = json.load(json_file)
			self.allPoly.clear()
			MyPolygon.count = 0
			for key,val in data.items():
				poly = MyPolygon()
				poly.points = [[p[0]*self.scale,p[1]*self.scale] for p in val["points"]]
				#poly.update_xywh()
				
				poly.myItems = val["items"]
				self.allPoly.append(poly)
		self.update()
		
	def reNumber(self):
		count = 0
		
		for r in self.allPoly:
			r.id = count
			count+=1
		MyPolygon.count = count+1
		self.update()
		
if __name__ == '__main__':

	app = QApplication(sys.argv)
	scale=1.0
	if len(sys.argv)>2: scale = float(sys.argv[2])
	ex = MyUI(sys.argv[1],scale)
	sys.exit(app.exec_())
