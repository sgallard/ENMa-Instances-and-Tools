Here is a tutorial for setting up the python virtual environment:

[https://tecadmin.net/use-virtualenv-with-python3/](https://tecadmin.net/use-virtualenv-with-python3/)

Pierre:

1. I created my Python virtual environement under:  

  > /Users/pkornp/Work/code/python/myvirtualenvironment

2. To activate it:

  > source /Users/pkornp/Work/code/python/myvirtualenvironment/bin/activate
  > 
  > Then I should see:
  > 
  > **(myvirtualenvironment)** cline:python pkornp$
  
3. From here, I can install packages:

  > - pip3 install numpy
  > - pip3 install Pyside2 
  > - pip3 install beautifulsoup4
  > - pip3 install opencv-python-headless
  >
  > NB: functools is included in the default python distribution. There's no need to install it. cv2 corresponds to opencv

4. From here, I can finally run the application

  > python3 annonews_base.py frontpage-example.jpg 0.8p
  
5. Then, in general, I just need then to steps 2 and 4


Sebastian Gallardo:

MODIFIED VERSION:
- 'convert_output.py' included: tool to convert JSON output to HBB-NPP input for BranchBound algorithm
- Also, added a button to generate HBB-NPP input directly, using Annotation Tool GUI.