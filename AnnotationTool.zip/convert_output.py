import sys, os
import random as rand
import json

def formatJson(filename, outputName):
    jsonFile = open(filename)
    jFormatted = json.load(jsonFile)
    jsonFile.close()
    dimensions = []
    print('Formatting JSON file...')
    minX = jFormatted["0"]['points'][0][0]
    maxX = minX
    minY = jFormatted["0"]['points'][0][1]
    maxY = minY
    for item in jFormatted:
        points = jFormatted[item]["points"]
        x0 = min([points[i][0] for i in range(len(points))])
        x1 = max([points[i][0] for i in range(len(points))])
        y0 = min([points[i][1] for i in range(len(points))])
        y1 = max([points[i][1] for i in range(len(points))])

        sorted_points = list(points)
        sorted_points.sort()
        top_left_x, top_left_y = sorted_points[0]
        width = int(x1 - x0)
        height = int(y1 - y0)
        dimensions.append(["rect"+item, top_left_x, top_left_y,width, height])

        if x0 < minX:
            minX = x0
        if x1 > maxX:
            maxX = x1
        if y0 < minY:
            minY = y0
        if y1 > maxY:
            maxY = y1
    
    outputFile = open(outputName, mode="w")
    binWidth = int(maxX - minX)
    binHeight = int(maxY - minY)
    outputFile.write(str(binWidth) + " " + str(binHeight)+ "\n")
    outputFile.write(str(len(dimensions)) + "\n")

    for item in dimensions:
        item[1]-=minX
        item[2]-=minY
        line = ' '.join(map(str, item))
        outputFile.write(line + '\n')
    
    outputFile.close()
    print("File created!")
    
        
    
print("TOOL TO CONVERT ANNOTATION TOOL OUTPUTS TO HBB-NPP INPUTS")
print("IMPORTANT: SCALE MUST BE 1, BECAUSE HBB-NPP ONLY USES INT VALUES AS ITEM DIMENSIONS")
if len(sys.argv) < 2:
    print("ERROR: need 2 arguments: inputJsonfile and outputFilename")
formatJson(sys.argv[1], sys.argv[2])