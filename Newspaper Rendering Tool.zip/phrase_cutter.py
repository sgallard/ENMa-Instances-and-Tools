"""
Based on Johanna code to split mnread phrases. Adapted by Sebastian Gallardo
"""

""" Cut a given phrase to fit box width
    @param phrase is the phrase we want to cut
    @param box_width is the width of the box/block IN PIXELS
"""

def cut_phrase(phrase, box_width, fnt):
    words = phrase.split() # We split each word of the list and place them in a liste

    line = [] # Correspond to the current line
    cutted_phrase = ""    
    words_width = 0 # total width of the words in the phrase
    number_of_spaces = 0 # number of spaces in the line
    fit = 0 # allows us to know if the space between words are between 0.8 and 1.25 
    space_width = float(fnt.getsize(" ")[0]) # use the function string_width() which give the width of a string to get the width of a space
    list_cutted_phrases = [] # final list with the 3 pieces of the phrase
    list_space_widths = [] #final list with the corresponding space width per line
    ## We add one by one the words of the phrase in a line. Once the space's width of the line are all between 80% and 125% of the standard width of a space, the current line is validate, and we do this process again in order to have 3 lines
    i=0
    while(i < len(words)): 
        line.append(words[i]) # We add the word to the current line
        words_width += float(fnt.getsize(words[i])[0]) #  We get the word's width and we add this width to the total width of the words in the line
        number_of_spaces = len(line) -1 # We get the number of spaces in the line
        if number_of_spaces == 0 and (box_width - words_width) < 0:
            #only 1 word doesn't fit. we need to split the word
            cutted_word = "" 
            ready = False
            add_offset_line = False
            for c in words[i]:
                if (not ready):
                    cutted_word+=c
                    if ((box_width - float(fnt.getsize(cutted_word+"-")[0])) < 0): #using a different interval to cut the word [0.9, 1.1].
                        line[len(line)-1] = cutted_word[0:len(cutted_word)-1]+"-" 
                        for word in  line : 
                            if word != line[len(line)-1] : # if this is not the last word
                                cutted_phrase += word + ' ' # we remake the phrase with spaces
                            else : 
                                cutted_phrase += word #we don't put extra space at the end of the line
                        list_cutted_phrases.append(cutted_phrase) # We add this piece of phrase at the list of pieces of phrase
                        list_space_widths.append(fit)
                        offset = cutted_word[-1]
                        ready = True
                else:
                    offset+=c
                    add_offset_line=True
            # We reset the parameters to start again with the next line
            cutted_phrase = ""
            fit = 0
            words_width = 0
            number_of_spaces = 0
            line = []

            if(add_offset_line): #if there are a cutted word, write the remaining characters in the next line.
                words[i] = offset
                i-=1 #restart from the last word with remaining offset
        elif number_of_spaces !=0: # if =0, error division by zero 
            fit = round((box_width - words_width) / (number_of_spaces * space_width),2) # We calculate if the spaces's widths are between 80 and 125% of the standard width of a space
            if (fit >= 0.8 and fit <= 1.25) : 
                for word in  line : 
                    if word != line[len(line)-1] : # if this is not the last word
                        cutted_phrase += word + ' ' # we remake the phrase with spaces
                    else : 
                        cutted_phrase += word #we don't put extra space at the end of the line
                list_cutted_phrases.append(cutted_phrase) # We add this piece of phrase at the list of pieces of phrase
                list_space_widths.append(fit)
                # We reset the parameters to start again with the next line
                cutted_phrase = ""
                fit = 0
                words_width = 0
                number_of_spaces = 0
                line = []
            elif (fit < 0.8): #we need to split the last word                
                cutted_word = "" 
                ready = False
                add_offset_line = False
                for c in words[i]:
                    if (not ready):
                        cutted_word+=c
                        fit = round((box_width - (words_width-float(fnt.getsize(words[i])[0])+float(fnt.getsize(cutted_word+"-")[0]))) / (number_of_spaces * space_width),2) # We calculate if the spaces's widths are between 80 and 125% of the standard width of a space
                        if (fit >= 0.9 and fit <= 1.1): #using a different interval to cut the word [0.9, 1.1].
                            line[len(line)-1] = cutted_word+"-" 
                            for word in  line : 
                                if word != line[len(line)-1] : # if this is not the last word
                                    cutted_phrase += word + ' ' # we remake the phrase with spaces
                                else : 
                                    cutted_phrase += word #we don't put extra space at the end of the line
                            list_cutted_phrases.append(cutted_phrase) # We add this piece of phrase at the list of pieces of phrase
                            list_space_widths.append(fit)
                            offset = ""
                            ready = True
                        elif (fit < 0.9 and len(cutted_word) > 1):
                            line[len(line)-1] = cutted_word[0:len(cutted_word) - 1]+"-" 
                            for word in  line : 
                                if word != line[len(line)-1] : # if this is not the last word
                                    cutted_phrase += word + ' ' # we remake the phrase with spaces
                                else : 
                                    cutted_phrase += word #we don't put extra space at the end of the line
                            list_cutted_phrases.append(cutted_phrase) # We add this piece of phrase at the list of pieces of phrase
                            fit = round((box_width - (words_width -float(fnt.getsize(words[i])[0]) + float(fnt.getsize(cutted_word[0:len(cutted_word) - 1]+"-")[0]))) / (number_of_spaces * space_width),2)
                            list_space_widths.append(fit)
                            offset = cutted_word[len(cutted_word) - 1] #offset = last character erased from previous line
                            ready = True
                        elif (fit < 0.9): #if the word still doesn't fit because of a single character, simply break the line before the word
                            del line[len(line)-1]
                            for word in  line : 
                                if word != line[len(line)-1] : # if this is not the last word
                                    cutted_phrase += word + ' ' # we remake the phrase with spaces
                                else : 
                                    cutted_phrase += word #we don't put extra space at the end of the line
                            list_cutted_phrases.append(cutted_phrase) # We add this piece of phrase at the list of pieces of phrase
                            if (number_of_spaces > 1):
                                fit = round((box_width - (words_width -float(fnt.getsize(words[i])[0]))) / ((number_of_spaces - 1) * space_width),2)
                            else:
                                fit = 1.0
                            list_space_widths.append(fit)
                            ready = True
                            add_offset_line = False
                            i-=1
                            break
                    else:
                        offset+=c
                        add_offset_line=True
                
                # We reset the parameters to start again with the next line
                cutted_phrase = ""
                fit = 0
                words_width = 0
                number_of_spaces = 0
                line = []

                if(add_offset_line): #if there are a cutted word, write the remaining characters in the next line.
                    words[i] = offset
                    i-=1 #restart from the last word with remaining offset
        i+=1

    if (len(line) > 0):     
        for word in line : 
            if word != line[len(line)-1] : # if this is not the last word
                cutted_phrase += word + ' ' # we remake the phrase with spaces
            else : 
                cutted_phrase += word #we don't put extra space at the end of the line
        list_cutted_phrases.append(cutted_phrase) # We add this piece of phrase at the list of pieces of phrase 
        list_space_widths.append(1.0)

    return list_cutted_phrases, list_space_widths
    
