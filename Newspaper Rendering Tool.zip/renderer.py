from textwrap import fill
from phrase_cutter import cut_phrase

import sys
from PIL import Image, ImageDraw, ImageFont
import json


def readFiles(json_file, layout_file):
    f= open(layout_file, "r")
    blocks = {}
    if f.mode == "r":
        line = f.readline()
        if (line.split(" ")[0] == "Score:"):
            score = line.strip("Score: ")
            line = f.readline()
        else:
            score = "-"
        line = line.strip().split(" ")
        W = int(line[0])
        H = int(line[1])
        Hmargin = int(line[2])
        Vmargin = int(line[3])
        f.readline()
        for line in f:
            name_xywh = line.strip().split(" ")
            blocks[name_xywh[0]] = (int(name_xywh[1]), int(name_xywh[2]), int(name_xywh[3]), int(name_xywh[4]))
        
    else:
        print("ERROR")
        return None
    f.close()
    #read json file
    f = open(json_file, "r")
    text_data = json.load(f)
    f.close()

    return text_data, blocks, (W,H,Hmargin,Vmargin, score)
    

def justify_text(text,fnt, bounding_box_width):
    words_in_text = text.split(" ")
    number_spaces = len(words_in_text) - 1
    index = 0    
    w, _ = fnt.getsize(text)
    while (number_spaces>0 and w < bounding_box_width):
        current_word = words_in_text[index%number_spaces]
        words_in_text[index%number_spaces]+=" "
        index+=1
        new_text = " ".join(words_in_text)
        w, _ = fnt.getsize(new_text)
        if (w > bounding_box_width):
            words_in_text[(index-1)%number_spaces] = current_word #restore current word if w > bounding box width
            break
    final_sentence = " ".join(words_in_text)
    return final_sentence


def convert_coordinates(coordinates, newspaper, h):
    return (coordinates[0], (newspaper[1] - coordinates[1]))

text_data, layout_data, newspaper_grid = readFiles(sys.argv[1], sys.argv[2])
#RECEIVE MAG FACTOR
magnification_factor = float(sys.argv[3])
nlines_threshold = int(sys.argv[4])

scale = 1 #scale ratio used just to display the image. NOT USED. KEEP IN 1
margin_percentage = int(text_data["margin_percentage"]) #margin at the left-right-top-bottom of the bounding box, computed as x% of the bounding box width
with Image.new("RGBA", (newspaper_grid[0]*scale,newspaper_grid[1]*scale), (255,255,255)) as im:
    draw = ImageDraw.Draw(im)
    #print("Score: ", newspaper_grid[-1])
    for block_code in layout_data:
        
        #draw text in a given font
        # draw text, full opacity
        margin = margin_percentage*layout_data[block_code][2]*scale/100.0 
        h_margin = margin_percentage*layout_data[block_code][3]*scale/100.0 
        # get a font, and magnify font size according to mag factor
        fnt = ImageFont.truetype("Fonts/"+text_data["font"]+".ttf", int(text_data[block_code]["headingFontSize"]*scale*magnification_factor))
        text_list, space_proportion = cut_phrase(text_data[block_code]["heading"], (layout_data[block_code][2] - 2*margin)*scale,  fnt)

        cut_text = "\n".join(text_list)
        bbox = draw.multiline_textbbox((0,0), cut_text, font=fnt, spacing=0)
        #_, h = draw.multiline_textsize(cut_text, font=fnt, spacing=0)
        h = bbox[3] - bbox[1]
        number_lines = len(text_list)

        while ((h+2*h_margin) > layout_data[block_code][3]):
            points = "..."
            text_list.remove(text_list[-1])
            if(len(text_list) == 0): #sometimes, even 1 line doesn't fit
                cut_text = ""
                break
            last_line_in_words = text_list[-1].strip().split(" ")
            last_line_with_points = " ".join(last_line_in_words[0:len(last_line_in_words)-1])
            text_list[-1] = last_line_with_points+"..." #erase last word of the body text to replace it with "..."
            cut_text = "\n".join(text_list) #add ... at the end

            bbox = draw.multiline_textbbox((0,0), cut_text, font=fnt, spacing=0)
            #_, h = draw.multiline_textsize(cut_text, font=fnt, spacing=0)
            h = bbox[3] - bbox[1]
            
        

        #put red border if number_lines > threshold
        if("color" in text_data[block_code]): 
            if(number_lines > nlines_threshold):
                draw.rectangle((convert_coordinates((scale*layout_data[block_code][0], scale*layout_data[block_code][1]), newspaper_grid, layout_data[block_code][3]), convert_coordinates((scale*(layout_data[block_code][0]+layout_data[block_code][2]), scale*(layout_data[block_code][1] + layout_data[block_code][3])), newspaper_grid, layout_data[block_code][3])), fill=text_data[block_code]["color"], outline="red", width=10)
            else:
                draw.rectangle((convert_coordinates((scale*layout_data[block_code][0], scale*layout_data[block_code][1]), newspaper_grid, layout_data[block_code][3]), convert_coordinates((scale*(layout_data[block_code][0]+layout_data[block_code][2]), scale*(layout_data[block_code][1] + layout_data[block_code][3])), newspaper_grid, layout_data[block_code][3])), fill=text_data[block_code]["color"], outline="black")
        else:
            if(number_lines > nlines_threshold):
                draw.rectangle((convert_coordinates((scale*layout_data[block_code][0], scale*layout_data[block_code][1]), newspaper_grid, layout_data[block_code][3]), convert_coordinates((scale*(layout_data[block_code][0]+layout_data[block_code][2]), scale*(layout_data[block_code][1] + layout_data[block_code][3])), newspaper_grid, layout_data[block_code][3])), outline="red", width=10)
            else:
                draw.rectangle((convert_coordinates((scale*layout_data[block_code][0], scale*layout_data[block_code][1]), newspaper_grid, layout_data[block_code][3]), convert_coordinates((scale*(layout_data[block_code][0]+layout_data[block_code][2]), scale*(layout_data[block_code][1] + layout_data[block_code][3])), newspaper_grid, layout_data[block_code][3])), outline="black")

        
        number_lines = len(text_list)
        #draw text word by word
        x_init = scale*(layout_data[block_code][0] + margin)
        #_, y_init = convert_coordinates((x_init,layout_data[block_code][1]),newspaper_grid)
        y_init = newspaper_grid[1] - layout_data[block_code][1] - layout_data[block_code][3]
        y_init+=h_margin
        i = 0
        for line in text_list:
            words = line.split(" ")
            draw.multiline_text((x_init, y_init), words[0], font=fnt, anchor="la", align="left", fill="black")
            last_word = words[0]
            offset = 0
            for word in words[1:]:
                offset += fnt.getsize(last_word)[0] + fnt.getsize(" ")[0]*float(space_proportion[i])
                draw.multiline_text((x_init+offset, y_init), word, font=fnt, anchor="la", align="left", fill="black")
                last_word = word
            y_init += fnt.getsize("\n")[1]
            i+=1

        # draw.multiline_text((scale*(layout_data[block_code][0] + margin), scale*(layout_data[block_code][1]+margin)), final_sentence, font=fnt, fill=1, anchor="la", align="center")

        vertical_empty_space = scale*(layout_data[block_code][3] - h - h_margin)

        if (vertical_empty_space > 0): 
            text_fnt = ImageFont.truetype("Fonts/"+text_data["font"]+".ttf", int(text_data[block_code]["textFontSize"]*scale*magnification_factor))

            text_list, space_proportion = cut_phrase(text_data[block_code]["text"], (layout_data[block_code][2] - 2*margin)*scale,  text_fnt)
            
            cut_text = "\n"+"\n".join(text_list)
            bbox = draw.multiline_textbbox((0,0), cut_text, font=text_fnt, spacing=0)
            w, text_vertical_space = bbox[2] - bbox[0], bbox[3] - bbox[1]
            #w, text_vertical_space =  draw.multiline_textsize(cut_text, font=text_fnt, spacing=0)
            #w, text_vertical_space =  text_fnt.getsize(cut_text)
            
            remaining_text= vertical_empty_space - text_vertical_space*scale
            points = ""
            while(remaining_text < 0):  
                points = "..."
                text_list.remove(text_list[-1])
                if(len(text_list) == 0): #sometimes, even 1 line doesn't fit
                    cut_text = ""
                    break
                last_line_in_words = text_list[-1].strip().split(" ")
                text_list[-1] = " ".join(last_line_in_words[0:len(last_line_in_words) -1]) #erase last word of the body text to replace it with "..."
                cut_text = "\n"+"\n".join(text_list)+points

                bbox = draw.multiline_textbbox((0,0), cut_text, font=text_fnt, spacing=0)
                #w, text_vertical_space =  draw.multiline_textsize(cut_text, font=text_fnt, spacing=0)
                w, text_vertical_space = bbox[2] - bbox[0], bbox[3] - bbox[1]
               
                remaining_text= vertical_empty_space - text_vertical_space*scale
            
            #justify per line
            text_list = cut_text.strip().split("\n")
            #draw text word by word
            x_init = scale*(layout_data[block_code][0] + margin)
            #y_init = scale*(layout_data[block_code][1]+layout_data[block_code][3] - vertical_empty_space)
            y_init = newspaper_grid[1] - layout_data[block_code][1] - layout_data[block_code][3]
            y_init+=(layout_data[block_code][3] - vertical_empty_space)
            y_init+=text_fnt.getsize("\n")[1]
            i=0
            for line in text_list:
                words = line.split(" ")
                draw.multiline_text((x_init, y_init), words[0], font=text_fnt, anchor="la", align="left", fill="black")
                last_word = words[0]
                offset = 0
                for word in words[1:]:
                    offset += text_fnt.getsize(last_word)[0] + text_fnt.getsize(" ")[0]*space_proportion[i] #TEST
                    draw.multiline_text((x_init+offset, y_init), word, font=text_fnt, anchor="la", align="left", fill="black")
                    last_word = word
                y_init += text_fnt.getsize("\n")[1]
                i+=1

            #draw.multiline_text((scale*(layout_data[block_code][0] + margin), scale*(layout_data[block_code][1]+layout_data[block_code][3] - vertical_empty_space)), final_sentence, font=text_fnt, fill=1, anchor="la", align="center")

            
    # write to file
    #im.show()
    filepath = (sys.argv[2]).strip().split("/")
    filename = filepath[-1].strip(".txt")
    im.save("outputs_png/"+filename+".png")